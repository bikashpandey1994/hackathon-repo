package com.hackthon.voiceProcessor;

public class SentimentRequestText {

	private String text;
	
	private String uuid;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
}
